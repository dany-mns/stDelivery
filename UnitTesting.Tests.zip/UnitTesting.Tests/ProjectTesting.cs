﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using stDelivery;
using DatabaseStDeliveryLibrary;
using SMTP;
using stDelivery.Kitchen;

namespace UnitTesting.Tests
{
    [TestClass]
    public class ProjectTesting
    {

        [TestMethod]
        public void CryptoVerify()
        {
            Assert.AreEqual("8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", Crypt.SHA256hash("admin"));
        }

        [TestMethod]
        public void TypeOfFoodVerify()
        {
            Assert.AreEqual((int)TypeOfFood.Pizza, 0);
            Assert.AreEqual((int)TypeOfFood.Desert, 5);
        }

        //[TestMethod]
        //[ExpectedException(typeof(Exception))]
        //public void CreateWrongFoodFactoryVerify()
        //{
        //    FoodFactory f = new FoodFactory(TypeOfFood.Undefined);
        //}
        
        [TestMethod]
        public void CreateDatabaseVerify()
        {
            Database db = Database.Instance();
            Assert.AreEqual(true, db.createDatabase());
        }


        [TestMethod]
        public void UpdateUserVerify()
        {
            Database db = Database.Instance();
            User user = new User();
            user.Email = "a@gmail.com";
            user.Parola = "sasd";
            Assert.AreEqual(true, db.UpdateUserIntoTable(user));
        }

        [TestMethod]
        public void DeleteUserVerify()
        {
            Database db = Database.Instance();
            User user = new User();
            user.Email = "a@gmail.com";
            user.Parola = "sasd";
            Assert.AreEqual(true, db.DeleteUserIntoTable(user));
        }

        [TestMethod]
        public void UserNumberVerify()
        {
            Database db = Database.Instance();
            Assert.AreEqual(0, db.userNumber());
        }


        [TestMethod]
        public void emailExistVerify()
        {
            Database db = Database.Instance();
            Assert.AreEqual(0, db.emailExist("a1@gmail.com"));
        }


        [TestMethod]
        public void clearDatabaseVerify()
        {
            Database db = Database.Instance();
            Assert.AreEqual(true, db.clearDatabase());
        }

        [TestMethod]
        public void GetCurrentUserVerify()
        {
            Database db = Database.Instance();
            Assert.AreEqual(null, db.getCurrentUser("", ""));
        }


        //[TestMethod]
        //[ExpectedException(typeof(Exception))]
        //public void SmtpVerify()
        //{
        //    Email email = new Email();
        //    Assert.AreEqual(null, email.SendEmail());
        //}
    }
}
